"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// deploy/windows/shims/server-only.js
var require_server_only = __commonJS({
  "deploy/windows/shims/server-only.js"(exports2, module2) {
    "use strict";
    module2.exports = {};
  }
});

// prisma/seed.ts
var import_client = require("@prisma/client");

// src/lib/auth/password.ts
var import_server_only = __toESM(require_server_only());
var import_node_crypto = require("node:crypto");

// node_modules/bcryptjs/index.js
var nextTick = typeof process !== "undefined" && process && typeof process.nextTick === "function" ? typeof setImmediate === "function" ? setImmediate : process.nextTick : setTimeout;
var BASE64_CODE = "./ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split("");

// src/lib/auth/password.ts
function scrypt(password, salt, keylen, options) {
  return new Promise((resolve, reject) => {
    (0, import_node_crypto.scrypt)(
      password,
      salt,
      keylen,
      options,
      (err, key) => err ? reject(err) : resolve(key)
    );
  });
}
var SCRYPT = { N: 16384, r: 8, p: 1, keylen: 32, maxmem: 96 * 1024 * 1024 };
var SCRYPT_PREFIX = "scrypt$";
async function scryptHash(plain, salt) {
  return scrypt(plain.normalize("NFKC"), salt, SCRYPT.keylen, {
    N: SCRYPT.N,
    r: SCRYPT.r,
    p: SCRYPT.p,
    maxmem: SCRYPT.maxmem
  });
}
async function hashPassword(plain) {
  const salt = (0, import_node_crypto.randomBytes)(16);
  const derived = await scryptHash(plain, salt);
  return `${SCRYPT_PREFIX}${SCRYPT.N}$${SCRYPT.r}$${SCRYPT.p}$${salt.toString("base64")}$${derived.toString("base64")}`;
}

// src/lib/seed.ts
var TOMAN = 10n;
var toman = (value) => BigInt(value) * TOMAN;
var DEFAULT_POLICIES = [
  { name: "\u0628\u06CC\u0634\u062A\u0631 \u0627\u0632 \u06F4 \u0633\u0627\u0639\u062A \u0645\u0627\u0646\u062F\u0647", minMinutesBefore: 240, maxMinutesBefore: null, penaltyPercent: 0 },
  { name: "\u0628\u06CC\u0646 \u06F2 \u062A\u0627 \u06F4 \u0633\u0627\u0639\u062A \u0645\u0627\u0646\u062F\u0647", minMinutesBefore: 120, maxMinutesBefore: 240, penaltyPercent: 15 },
  { name: "\u0628\u06CC\u0646 \u06F1 \u062A\u0627 \u06F2 \u0633\u0627\u0639\u062A \u0645\u0627\u0646\u062F\u0647", minMinutesBefore: 60, maxMinutesBefore: 120, penaltyPercent: 25 },
  { name: "\u0628\u06CC\u0646 \u06F3\u06F0 \u062F\u0642\u06CC\u0642\u0647 \u062A\u0627 \u06F1 \u0633\u0627\u0639\u062A \u0645\u0627\u0646\u062F\u0647", minMinutesBefore: 30, maxMinutesBefore: 60, penaltyPercent: 30 },
  { name: "\u06A9\u0645\u062A\u0631 \u0627\u0632 \u06F3\u06F0 \u062F\u0642\u06CC\u0642\u0647 \u0645\u0627\u0646\u062F\u0647", minMinutesBefore: 0, maxMinutesBefore: 30, penaltyPercent: 50 }
];
var COURTS = [
  {
    name: "\u0632\u0645\u06CC\u0646 \u06F1",
    slug: "court-1",
    description: "\u0632\u0645\u06CC\u0646 \u0627\u0635\u0644\u06CC \u2014 \u0633\u0631\u067E\u0648\u0634\u06CC\u062F\u0647 \u0628\u0627 \u0646\u0648\u0631\u067E\u0631\u062F\u0627\u0632\u06CC \u062D\u0631\u0641\u0647\u200C\u0627\u06CC",
    basePrice: toman(4e5),
    peakPrice: toman(55e4),
    imageUrl: "/images/login/court-1.jpg"
  },
  {
    name: "\u0632\u0645\u06CC\u0646 \u06F2",
    slug: "court-2",
    description: "\u0632\u0645\u06CC\u0646 \u0634\u0645\u0627\u0631\u0647 \u062F\u0648 \u2014 \u0645\u0646\u0627\u0633\u0628 \u0645\u0633\u0627\u0628\u0642\u0627\u062A \u062F\u0648\u0628\u0644",
    basePrice: toman(38e4),
    peakPrice: toman(52e4),
    imageUrl: "/images/login/court-2.jpg"
  },
  {
    name: "\u0632\u0645\u06CC\u0646 \u06F3",
    slug: "court-3",
    description: "\u0632\u0645\u06CC\u0646 \u0634\u0645\u0627\u0631\u0647 \u0633\u0647 \u2014 \u0631\u0648\u0628\u0627\u0632 \u0628\u0627 \u0686\u0645\u0646 \u0645\u0635\u0646\u0648\u0639\u06CC \u062F\u0631\u062C\u0647 \u06CC\u06A9",
    basePrice: toman(35e4),
    peakPrice: toman(48e4),
    imageUrl: "/images/login/court-4.jpg"
  }
];
var SAMPLE_PLAYERS = [
  { username: "ali", firstName: "\u0639\u0644\u06CC", lastName: "\u0645\u062D\u0645\u062F\u06CC", phone: "09121111111", level: "A", points: 250, gender: "MALE" },
  { username: "sara", firstName: "\u0633\u0627\u0631\u0627", lastName: "\u0631\u0636\u0627\u06CC\u06CC", phone: "09122222222", level: "B_PLUS", points: 180, gender: "FEMALE" },
  { username: "reza", firstName: "\u0631\u0636\u0627", lastName: "\u06A9\u0631\u06CC\u0645\u06CC", phone: "09123333333", level: "B", points: 120, gender: "MALE" },
  { username: "niloofar", firstName: "\u0646\u06CC\u0644\u0648\u0641\u0631", lastName: "\u0627\u062D\u0645\u062F\u06CC", phone: "09124444444", level: "A_MINUS", points: 210, gender: "FEMALE" },
  { username: "mohammad", firstName: "\u0645\u062D\u0645\u062F", lastName: "\u062D\u0633\u06CC\u0646\u06CC", phone: "09125555555", level: "C_PLUS", points: 60, gender: "MALE" },
  { username: "mina", firstName: "\u0645\u06CC\u0646\u0627", lastName: "\u0635\u0627\u062F\u0642\u06CC", phone: "09126666666", level: "C", points: 40, gender: "FEMALE" },
  { username: "amir", firstName: "\u0627\u0645\u06CC\u0631", lastName: "\u0646\u0648\u0631\u06CC", phone: "09127777777", level: "B_MINUS", points: 95, gender: "MALE" },
  { username: "zahra", firstName: "\u0632\u0647\u0631\u0627", lastName: "\u0645\u0648\u0633\u0648\u06CC", phone: "09128888888", level: "D_PLUS", points: 15, gender: "FEMALE" }
];
async function runSeed(prisma2, log = () => {
}, options = {}) {
  const adminUsername = process.env.SEED_ADMIN_USERNAME || "admin";
  const adminPassword = process.env.SEED_ADMIN_PASSWORD || "Admin@12345";
  const adminPhone = process.env.SEED_ADMIN_PHONE || "09120000000";
  const admin = await prisma2.user.upsert({
    where: { username: adminUsername },
    update: { role: "ADMIN" },
    create: {
      username: adminUsername,
      passwordHash: await hashPassword(adminPassword),
      phone: adminPhone,
      phoneVerifiedAt: /* @__PURE__ */ new Date(),
      role: "ADMIN",
      profile: { create: { firstName: "\u0645\u062F\u06CC\u0631", lastName: "\u0628\u0627\u0634\u06AF\u0627\u0647", level: "A_PLUS" } },
      wallet: { create: { balance: toman(5e6) } }
    }
  });
  log(`\u2705 \u062D\u0633\u0627\u0628 \u0645\u062F\u06CC\u0631 \u0622\u0645\u0627\u062F\u0647 \u0627\u0633\u062A \u2014 \u0646\u0627\u0645 \u06A9\u0627\u0631\u0628\u0631\u06CC: ${adminUsername}`);
  const policyCount = await prisma2.cancellationPolicy.count();
  if (policyCount === 0) {
    await prisma2.cancellationPolicy.createMany({ data: DEFAULT_POLICIES });
    log(`\u2705 ${DEFAULT_POLICIES.length} \u067E\u0644\u0647\u200C\u06CC \u062C\u0631\u06CC\u0645\u0647\u200C\u06CC \u0644\u063A\u0648 \u062B\u0628\u062A \u0634\u062F`);
  }
  await prisma2.appSetting.upsert({
    where: { key: "wallet.topup.presets" },
    update: {},
    create: {
      key: "wallet.topup.presets",
      value: [2e5, 5e5, 1e6, 2e6],
      description: "\u0645\u0628\u0627\u0644\u063A \u067E\u06CC\u0634\u0646\u0647\u0627\u062F\u06CC \u0634\u0627\u0631\u0698 \u06A9\u06CC\u0641 \u067E\u0648\u0644 (\u062A\u0648\u0645\u0627\u0646)"
    }
  });
  await prisma2.appSetting.upsert({
    where: { key: "club.contact" },
    update: {},
    create: {
      key: "club.contact",
      value: { phone: "021-00000000", instagram: "@persianpadel", address: "\u062A\u0647\u0631\u0627\u0646" },
      description: "\u0627\u0637\u0644\u0627\u0639\u0627\u062A \u062A\u0645\u0627\u0633 \u0628\u0627\u0634\u06AF\u0627\u0647"
    }
  });
  if (options.essentialsOnly) {
    log("\u2139\uFE0F \u062F\u0627\u062F\u0647\u200C\u06CC \u0646\u0645\u0648\u0646\u0647 (\u0632\u0645\u06CC\u0646\u060C \u0628\u0627\u0632\u06CC\u06A9\u0646\u060C \u062A\u0648\u0631\u0646\u0648\u0645\u0646\u062A\u060C \u0628\u0646\u0631\u060C \u06A9\u0627\u0644\u0627\u060C \u062E\u0628\u0631) \u0648\u0627\u0631\u062F \u0646\u0634\u062F.");
    return { adminUsername, players: 0, courts: 0 };
  }
  for (const [index, court] of COURTS.entries()) {
    const created = await prisma2.court.upsert({
      where: { slug: court.slug },
      update: {},
      create: {
        name: court.name,
        slug: court.slug,
        description: court.description,
        basePrice: court.basePrice,
        imageUrl: court.imageUrl,
        slotDurationMinutes: 90,
        openingMinute: 10 * 60,
        closingMinute: 23 * 60,
        maxConsecutiveSlots: 4,
        minLeadTimeMinutes: 30,
        advanceBookingDays: 30,
        sortOrder: index
      }
    });
    const hasRule = await prisma2.courtPricingRule.count({ where: { courtId: created.id } });
    if (hasRule === 0) {
      await prisma2.courtPricingRule.create({
        data: {
          courtId: created.id,
          name: "\u0633\u0627\u0639\u0627\u062A \u067E\u0631\u062A\u0642\u0627\u0636\u0627 (\u0639\u0635\u0631 \u0648 \u0634\u0628)",
          startMinute: 16 * 60,
          endMinute: 23 * 60,
          daysOfWeek: [],
          price: court.peakPrice,
          priority: 10
        }
      });
    }
  }
  log(`\u2705 ${COURTS.length} \u0632\u0645\u06CC\u0646 \u0628\u0627 \u0642\u06CC\u0645\u062A\u200C\u06AF\u0630\u0627\u0631\u06CC \u0633\u0627\u0639\u0627\u062A \u067E\u0631\u062A\u0642\u0627\u0636\u0627 \u0622\u0645\u0627\u062F\u0647 \u0634\u062F`);
  const playerPassword = await hashPassword("Player@12345");
  const players = [];
  for (const p of SAMPLE_PLAYERS) {
    const user = await prisma2.user.upsert({
      where: { username: p.username },
      update: {},
      create: {
        username: p.username,
        passwordHash: playerPassword,
        phone: p.phone,
        phoneVerifiedAt: /* @__PURE__ */ new Date(),
        role: "PLAYER",
        profile: {
          create: { firstName: p.firstName, lastName: p.lastName, level: p.level, gender: p.gender }
        },
        wallet: { create: { balance: toman(2e6) } }
      },
      include: { profile: true }
    });
    const existingPoints = await prisma2.pointsTransaction.findUnique({
      where: { referenceKey: `seed:points:${user.id}` }
    });
    if (!existingPoints && p.points > 0) {
      await prisma2.$transaction(async (tx) => {
        await tx.pointsTransaction.create({
          data: {
            userId: user.id,
            type: "ADMIN_CREDIT",
            amount: p.points,
            balanceBefore: 0,
            balanceAfter: p.points,
            description: "\u0627\u0645\u062A\u06CC\u0627\u0632 \u0627\u0648\u0644\u06CC\u0647\u200C\u06CC \u062C\u0627\u0645\u0639\u0647\u200C\u06CC \u0628\u0627\u0634\u06AF\u0627\u0647",
            referenceKey: `seed:points:${user.id}`,
            performedById: admin.id
          }
        });
        await tx.profile.update({ where: { userId: user.id }, data: { points: p.points } });
      });
    }
    players.push(user);
  }
  log(`\u2705 ${players.length} \u0628\u0627\u0632\u06CC\u06A9\u0646 \u0646\u0645\u0648\u0646\u0647 \u0633\u0627\u062E\u062A\u0647 \u0634\u062F (\u0631\u0645\u0632 \u0639\u0628\u0648\u0631: Player@12345)`);
  const existingTournament = await prisma2.tournament.findUnique({
    where: { slug: "jam-tabestane-persian-padel" }
  });
  if (!existingTournament) {
    const start = new Date(Date.now() + 14 * 864e5);
    const end = new Date(start.getTime() + 8 * 36e5);
    const courts = await prisma2.court.findMany({ select: { id: true } });
    const tournament = await prisma2.tournament.create({
      data: {
        name: "\u062C\u0627\u0645 \u062A\u0627\u0628\u0633\u062A\u0627\u0646\u0647 \u067E\u0631\u0634\u06CC\u0646 \u067E\u062F\u0644",
        slug: "jam-tabestane-persian-padel",
        description: "\u0627\u0648\u0644\u06CC\u0646 \u062F\u0648\u0631\u0647\u200C\u06CC \u062C\u0627\u0645 \u062A\u0627\u0628\u0633\u062A\u0627\u0646\u0647 \u0628\u0627\u0634\u06AF\u0627\u0647 \u067E\u0631\u0634\u06CC\u0646 \u067E\u062F\u0644. \u0645\u0631\u062D\u0644\u0647\u200C\u06CC \u06AF\u0631\u0648\u0647\u06CC \u0648 \u0633\u067E\u0633 \u062D\u0630\u0641\u06CC\u060C \u0628\u0627 \u062C\u0648\u0627\u06CC\u0632 \u0646\u0642\u062F\u06CC \u0648 \u0627\u0645\u062A\u06CC\u0627\u0632 \u0628\u0627\u0634\u06AF\u0627\u0647\u06CC \u0628\u0631\u0627\u06CC \u062A\u06CC\u0645\u200C\u0647\u0627\u06CC \u0628\u0631\u062A\u0631.",
        type: "GROUP_KNOCKOUT",
        status: "REGISTRATION_OPEN",
        startsAt: start,
        endsAt: end,
        registrationClosesAt: new Date(start.getTime() - 2 * 864e5),
        maxTeams: 8,
        minTeams: 4,
        entryFee: toman(5e5),
        splitFeeBetweenPartners: true,
        partnerMode: "PLAYER_CHOICE",
        groupCount: 2,
        advancingPerGroup: 2,
        hasThirdPlaceMatch: true,
        pointsForWin: 3,
        pointsForDraw: 1,
        createdById: admin.id,
        courts: { create: courts.map((c) => ({ courtId: c.id })) },
        levelRules: {
          create: {
            type: "RANGE",
            slot1Levels: ["A_PLUS", "A", "A_MINUS"],
            slot2Levels: ["B_PLUS", "B", "B_MINUS"],
            orderInsensitive: true,
            description: "\u0647\u0631 \u062A\u06CC\u0645 \u0628\u0627\u06CC\u062F \u0627\u0632 \u06CC\u06A9 \u0628\u0627\u0632\u06CC\u06A9\u0646 \u0633\u0637\u062D A \u0648 \u06CC\u06A9 \u0628\u0627\u0632\u06CC\u06A9\u0646 \u0633\u0637\u062D B \u062A\u0634\u06A9\u06CC\u0644 \u0634\u0648\u062F."
          }
        },
        pointsRules: {
          create: [
            { rank: 1, pointsPerPlayer: 100, label: "\u0642\u0647\u0631\u0645\u0627\u0646" },
            { rank: 2, pointsPerPlayer: 50, label: "\u0646\u0627\u06CC\u0628\u200C\u0642\u0647\u0631\u0645\u0627\u0646" },
            { rank: 3, pointsPerPlayer: 30, label: "\u0645\u0642\u0627\u0645 \u0633\u0648\u0645" }
          ]
        }
      }
    });
    log(`\u2705 \u062A\u0648\u0631\u0646\u0648\u0645\u0646\u062A \u0646\u0645\u0648\u0646\u0647 \u0633\u0627\u062E\u062A\u0647 \u0634\u062F: ${tournament.name}`);
  }
  if (await prisma2.banner.count() === 0) {
    await prisma2.banner.createMany({
      data: [
        {
          title: "\u062C\u0627\u0645 \u062A\u0627\u0628\u0633\u062A\u0627\u0646\u0647 \u067E\u0631\u0634\u06CC\u0646 \u067E\u062F\u0644",
          subtitle: "\u062B\u0628\u062A\u200C\u0646\u0627\u0645 \u0628\u0627\u0632 \u0627\u0633\u062A \u2014 \u062A\u06CC\u0645 \u062E\u0648\u062F \u0631\u0627 \u0628\u0633\u0627\u0632\u06CC\u062F \u0648 \u0628\u0631\u0627\u06CC \u0642\u0647\u0631\u0645\u0627\u0646\u06CC \u0628\u062C\u0646\u06AF\u06CC\u062F.",
          imageUrl: "/images/login/court-1.jpg",
          linkUrl: "/tournaments",
          sortOrder: 0
        },
        {
          title: "\u0641\u0631\u0648\u0634\u06AF\u0627\u0647 \u0628\u0627\u0634\u06AF\u0627\u0647 \u0631\u0627\u0647\u200C\u0627\u0646\u062F\u0627\u0632\u06CC \u0634\u062F",
          subtitle: "\u0631\u0627\u06A9\u062A\u060C \u062A\u0648\u067E \u0648 \u0644\u0648\u0627\u0632\u0645 \u0648\u0631\u0632\u0634\u06CC \u0631\u0627 \u0628\u0627 \u0627\u0645\u062A\u06CC\u0627\u0632 \u06CC\u0627 \u0627\u0632 \u06A9\u06CC\u0641 \u067E\u0648\u0644 \u0628\u062E\u0631\u06CC\u062F.",
          imageUrl: "/images/login/court-3.jpg",
          linkUrl: "/market",
          sortOrder: 1
        },
        {
          title: "\u0633\u0627\u0639\u0627\u062A \u067E\u0631\u062A\u0642\u0627\u0636\u0627 \u0631\u0632\u0631\u0648 \u06A9\u0646\u06CC\u062F",
          subtitle: "\u0632\u0645\u06CC\u0646\u200C\u0647\u0627\u06CC \u0639\u0635\u0631 \u0632\u0648\u062F\u062A\u0631 \u062A\u06A9\u0645\u06CC\u0644 \u0645\u06CC\u200C\u0634\u0648\u0646\u062F \u2014 \u0647\u0645\u06CC\u0646 \u062D\u0627\u0644\u0627 \u0631\u0632\u0631\u0648 \u06A9\u0646\u06CC\u062F.",
          imageUrl: "/images/login/court-2.jpg",
          linkUrl: "/booking",
          sortOrder: 2
        }
      ]
    });
    log("\u2705 \u06F3 \u0628\u0646\u0631 \u0646\u0645\u0648\u0646\u0647 \u0633\u0627\u062E\u062A\u0647 \u0634\u062F");
  }
  const PRODUCTS = [
    {
      name: "\u0631\u0627\u06A9\u062A \u067E\u062F\u0644 \u062D\u0631\u0641\u0647\u200C\u0627\u06CC",
      slug: "pro-racket",
      category: "RACKET",
      description: "\u0631\u0627\u06A9\u062A \u06A9\u0631\u0628\u0646\u06CC \u0645\u062E\u0635\u0648\u0635 \u0628\u0627\u0632\u06CC\u06A9\u0646\u0627\u0646 \u0633\u0637\u062D A \u0648 B \u0628\u0627 \u062A\u0639\u0627\u062F\u0644 \u0645\u06CC\u0627\u0646\u06CC.",
      pricePoints: 1200,
      priceToman: 48e5,
      stock: 6
    },
    {
      name: "\u0631\u0627\u06A9\u062A \u067E\u062F\u0644 \u0645\u0628\u062A\u062F\u06CC",
      slug: "starter-racket",
      category: "RACKET",
      description: "\u0633\u0628\u06A9 \u0648 \u06A9\u0646\u062A\u0631\u0644\u200C\u067E\u0630\u06CC\u0631\u060C \u0645\u0646\u0627\u0633\u0628 \u0634\u0631\u0648\u0639 \u0628\u0627\u0632\u06CC.",
      pricePoints: 600,
      priceToman: 22e5,
      stock: 10
    },
    {
      name: "\u0628\u0633\u062A\u0647 \u06F3 \u0639\u062F\u062F\u06CC \u062A\u0648\u067E \u067E\u062F\u0644",
      slug: "ball-pack-3",
      category: "BALL",
      description: "\u062A\u0648\u067E \u0627\u0633\u062A\u0627\u0646\u062F\u0627\u0631\u062F \u0645\u0633\u0627\u0628\u0642\u0627\u062A\u060C \u0628\u0633\u062A\u0647\u200C\u06CC \u0633\u0647\u200C\u062A\u0627\u06CC\u06CC.",
      pricePoints: 90,
      priceToman: 38e4,
      stock: 40
    },
    {
      name: "\u062A\u06CC\u0634\u0631\u062A \u0628\u0627\u0634\u06AF\u0627\u0647",
      slug: "club-tshirt",
      category: "APPAREL",
      description: "\u062A\u06CC\u0634\u0631\u062A \u0631\u0633\u0645\u06CC \u067E\u0631\u0634\u06CC\u0646 \u067E\u062F\u0644 \u0628\u0627 \u067E\u0627\u0631\u0686\u0647\u200C\u06CC \u062E\u0646\u06A9.",
      pricePoints: 250,
      priceToman: 89e4,
      stock: 18
    },
    {
      name: "\u0645\u0686\u200C\u0628\u0646\u062F \u0648\u0631\u0632\u0634\u06CC",
      slug: "wristband",
      category: "ACCESSORY",
      description: "\u062C\u0641\u062A \u0645\u0686\u200C\u0628\u0646\u062F \u062C\u0630\u0628 \u0639\u0631\u0642.",
      pricePoints: 60,
      priceToman: 19e4,
      stock: 30
    },
    {
      name: "\u06CC\u06A9 \u062C\u0644\u0633\u0647 \u062A\u0645\u0631\u06CC\u0646 \u062E\u0635\u0648\u0635\u06CC",
      slug: "private-session",
      category: "SERVICE",
      description: "\u06CC\u06A9 \u062C\u0644\u0633\u0647 \u062A\u0645\u0631\u06CC\u0646 \u06F6\u06F0 \u062F\u0642\u06CC\u0642\u0647\u200C\u0627\u06CC \u0628\u0627 \u0645\u0631\u0628\u06CC \u0628\u0627\u0634\u06AF\u0627\u0647.",
      pricePoints: 800,
      priceToman: null,
      stock: 8
    }
  ];
  for (const [index, p] of PRODUCTS.entries()) {
    await prisma2.storeProduct.upsert({
      where: { slug: p.slug },
      update: {},
      create: {
        name: p.name,
        slug: p.slug,
        description: p.description,
        category: p.category,
        pricePoints: p.pricePoints,
        priceRial: p.priceToman ? toman(p.priceToman) : null,
        stock: p.stock,
        isActive: true,
        sortOrder: index
      }
    });
  }
  log(`\u2705 ${PRODUCTS.length} \u06A9\u0627\u0644\u0627\u06CC \u0641\u0631\u0648\u0634\u06AF\u0627\u0647 \u0622\u0645\u0627\u062F\u0647 \u0634\u062F`);
  const ARTICLES = [
    {
      slug: "\u06AF\u0632\u0627\u0631\u0634-\u0641\u06CC\u0646\u0627\u0644-\u062C\u0627\u0645-\u062A\u0627\u0628\u0633\u062A\u0627\u0646\u0647",
      title: "\u06AF\u0632\u0627\u0631\u0634 \u0641\u06CC\u0646\u0627\u0644 \u062C\u0627\u0645 \u062A\u0627\u0628\u0633\u062A\u0627\u0646\u0647: \u0642\u0647\u0631\u0645\u0627\u0646\u06CC \u062F\u0631 \u062A\u0627\u06CC\u200C\u0628\u0631\u06CC\u06A9 \u0633\u062A \u0633\u0648\u0645",
      excerpt: "\u0641\u06CC\u0646\u0627\u0644 \u062C\u0627\u0645 \u062A\u0627\u0628\u0633\u062A\u0627\u0646\u0647 \u0628\u0627 \u06CC\u06A9 \u062A\u0627\u06CC\u200C\u0628\u0631\u06CC\u06A9 \u0646\u0641\u0633\u200C\u06AF\u06CC\u0631 \u062F\u0631 \u0633\u062A \u0633\u0648\u0645 \u062A\u0645\u0627\u0645 \u0634\u062F. \u0645\u0631\u0648\u0631 \u06A9\u0627\u0645\u0644 \u0645\u0633\u0627\u0628\u0642\u0647 \u0648 \u0635\u062D\u0628\u062A\u200C\u0647\u0627\u06CC \u062A\u06CC\u0645 \u0642\u0647\u0631\u0645\u0627\u0646.",
      body: `\u0641\u06CC\u0646\u0627\u0644 \u062C\u0627\u0645 \u062A\u0627\u0628\u0633\u062A\u0627\u0646\u0647 \u067E\u0631\u0634\u06CC\u0646 \u067E\u062F\u0644 \u0639\u0635\u0631 \u067E\u0646\u062C\u200C\u0634\u0646\u0628\u0647 \u0631\u0648\u06CC \u0632\u0645\u06CC\u0646 \u0634\u0645\u0627\u0631\u0647 \u06CC\u06A9 \u0628\u0631\u06AF\u0632\u0627\u0631 \u0634\u062F \u0648 \u062A\u0627 \u0622\u062E\u0631\u06CC\u0646 \u062A\u0648\u067E\u060C \u0628\u0631\u0646\u062F\u0647\u200C\u0627\u0634 \u0645\u0639\u0644\u0648\u0645 \u0646\u0628\u0648\u062F.

\u0633\u062A \u0627\u0648\u0644 \u0631\u0627 \u0645\u062D\u0645\u062F\u06CC \u0648 \u0631\u0636\u0627\u06CC\u06CC \u0628\u0627 \u0627\u062E\u062A\u0644\u0627\u0641 \u06F6 \u0628\u0631 \u06F4 \u0628\u0631\u062F\u0646\u062F. \u0641\u0634\u0627\u0631 \u0633\u0631\u0648\u06CC\u0633\u200C\u0647\u0627\u06CC \u0627\u0648\u0644 \u0648 \u067E\u0648\u0634\u0634 \u062E\u0648\u0628 \u062F\u06CC\u0648\u0627\u0631 \u067E\u0634\u062A\u06CC\u060C \u06A9\u0627\u0631 \u0631\u0627 \u0628\u0631\u0627\u06CC \u062D\u0631\u06CC\u0641 \u0633\u062E\u062A \u06A9\u0631\u062F\u0647 \u0628\u0648\u062F.

\u062F\u0631 \u0633\u062A \u062F\u0648\u0645 \u0648\u0631\u0642 \u0628\u0631\u06AF\u0634\u062A. \u0627\u062D\u0645\u062F\u06CC \u0648 \u06A9\u0631\u06CC\u0645\u06CC \u0628\u0627 \u062A\u063A\u06CC\u06CC\u0631 \u0622\u0631\u0627\u06CC\u0634 \u0648 \u0628\u0627\u0632\u06CC \u0646\u0632\u062F\u06CC\u06A9\u200C\u062A\u0631 \u0628\u0647 \u062A\u0648\u0631\u060C \u0633\u062A \u0631\u0627 \u06F6 \u0628\u0631 \u06F3 \u06AF\u0631\u0641\u062A\u0646\u062F \u0648 \u0645\u0633\u0627\u0628\u0642\u0647 \u0628\u0647 \u0633\u062A \u0633\u0648\u0645 \u06A9\u0634\u06CC\u062F.

\u0633\u062A \u0633\u0648\u0645 \u062A\u0627 \u06F6\u2013\u06F6 \u067E\u06CC\u0634 \u0631\u0641\u062A \u0648 \u062F\u0631 \u062A\u0627\u06CC\u200C\u0628\u0631\u06CC\u06A9\u060C \u062F\u0648 \u0627\u0645\u062A\u06CC\u0627\u0632 \u067E\u06CC\u0627\u067E\u06CC \u0631\u0648\u06CC \u0627\u0633\u0645\u0634\u060C \u06A9\u0627\u0631 \u0631\u0627 \u062A\u0645\u0627\u0645 \u06A9\u0631\u062F. \u062C\u0627\u0645 \u0628\u0647 \u062A\u06CC\u0645 \u0645\u062D\u0645\u062F\u06CC / \u0631\u0636\u0627\u06CC\u06CC \u0631\u0633\u06CC\u062F \u0648 \u06F1\u06F0\u06F0 \u0627\u0645\u062A\u06CC\u0627\u0632 \u0628\u0627\u0634\u06AF\u0627\u0647\u06CC \u0628\u0647 \u0647\u0631 \u0628\u0627\u0632\u06CC\u06A9\u0646 \u062A\u0639\u0644\u0642 \u06AF\u0631\u0641\u062A.`,
      coverUrl: "/images/login/court-1.jpg",
      isPinned: true
    },
    {
      slug: "\u0686\u06AF\u0648\u0646\u0647-\u062F\u06CC\u0648\u0627\u0631-\u0631\u0627-\u062F\u0631\u0633\u062A-\u0628\u0627\u0632\u06CC-\u06A9\u0646\u06CC\u0645",
      title: "\u0622\u0645\u0648\u0632\u0634: \u0686\u06AF\u0648\u0646\u0647 \u062F\u06CC\u0648\u0627\u0631 \u067E\u0634\u062A\u06CC \u0631\u0627 \u062F\u0631\u0633\u062A \u0628\u0627\u0632\u06CC \u06A9\u0646\u06CC\u0645",
      excerpt: "\u0631\u0627\u06CC\u062C\u200C\u062A\u0631\u06CC\u0646 \u0627\u0634\u062A\u0628\u0627\u0647 \u0628\u0627\u0632\u06CC\u06A9\u0646\u0627\u0646 \u062A\u0627\u0632\u0647\u200C\u06A9\u0627\u0631 \u067E\u062F\u0644\u060C \u0639\u062C\u0644\u0647 \u062F\u0631 \u0636\u0631\u0628\u0647\u200C\u06CC \u0628\u0631\u06AF\u0634\u062A\u06CC \u0627\u0632 \u062F\u06CC\u0648\u0627\u0631 \u0627\u0633\u062A.",
      body: `\u062F\u06CC\u0648\u0627\u0631\u060C \u0686\u06CC\u0632\u06CC \u0627\u0633\u062A \u06A9\u0647 \u067E\u062F\u0644 \u0631\u0627 \u0627\u0632 \u062A\u0646\u06CC\u0633 \u062C\u062F\u0627 \u0645\u06CC\u200C\u06A9\u0646\u062F \u2014 \u0648 \u0647\u0645\u0627\u0646 \u0686\u06CC\u0632\u06CC \u0627\u0633\u062A \u06A9\u0647 \u0628\u06CC\u0634\u062A\u0631 \u0628\u0627\u0632\u06CC\u06A9\u0646\u0627\u0646 \u062A\u0627\u0632\u0647\u200C\u06A9\u0627\u0631 \u0627\u0632 \u0622\u0646 \u0645\u06CC\u200C\u062A\u0631\u0633\u0646\u062F.

**\u06CC\u06A9 \u0642\u062F\u0645 \u0639\u0642\u0628\u200C\u062A\u0631 \u0628\u0627\u06CC\u0633\u062A\u06CC\u062F.** \u0628\u06CC\u0634\u062A\u0631 \u062E\u0637\u0627\u0647\u0627 \u0627\u0632 \u0627\u06CC\u0646 \u0645\u06CC\u200C\u0622\u06CC\u062F \u06A9\u0647 \u062E\u06CC\u0644\u06CC \u0646\u0632\u062F\u06CC\u06A9 \u0628\u0647 \u062F\u06CC\u0648\u0627\u0631 \u0645\u06CC\u200C\u0627\u06CC\u0633\u062A\u06CC\u0645 \u0648 \u062A\u0648\u067E \u062F\u0631 \u0628\u062F\u0646\u0645\u0627\u0646 \u06AF\u06CC\u0631 \u0645\u06CC\u200C\u06A9\u0646\u062F. \u0641\u0627\u0635\u0644\u0647 \u0628\u06AF\u06CC\u0631\u06CC\u062F \u0648 \u0628\u06AF\u0630\u0627\u0631\u06CC\u062F \u062A\u0648\u067E \u0628\u06CC\u0627\u06CC\u062F.

**\u0635\u0628\u0631 \u06A9\u0646\u06CC\u062F \u062A\u0627 \u062A\u0648\u067E \u0628\u0631\u06AF\u0631\u062F\u062F.** \u062A\u0648\u067E \u067E\u0633 \u0627\u0632 \u0628\u0631\u062E\u0648\u0631\u062F \u0628\u0627 \u062F\u06CC\u0648\u0627\u0631 \u0633\u0631\u0639\u062A\u0634 \u06A9\u0645 \u0645\u06CC\u200C\u0634\u0648\u062F\u061B \u0627\u06AF\u0631 \u0632\u0648\u062F\u062A\u0631 \u0636\u0631\u0628\u0647 \u0628\u0632\u0646\u06CC\u062F\u060C \u06A9\u0646\u062A\u0631\u0644 \u0631\u0627 \u0627\u0632 \u062F\u0633\u062A \u0645\u06CC\u200C\u062F\u0647\u06CC\u062F.

**\u0631\u0627\u06A9\u062A \u0631\u0627 \u067E\u0627\u06CC\u06CC\u0646 \u0646\u06AF\u0647 \u062F\u0627\u0631\u06CC\u062F.** \u0636\u0631\u0628\u0647\u200C\u06CC \u0628\u0631\u06AF\u0634\u062A\u06CC \u0627\u0632 \u062F\u06CC\u0648\u0627\u0631 \u0645\u0639\u0645\u0648\u0644\u0627\u064B \u067E\u0627\u06CC\u06CC\u0646\u200C\u062A\u0631 \u0627\u0632 \u06A9\u0645\u0631 \u0627\u0633\u062A. \u0631\u0627\u06A9\u062A \u0622\u0645\u0627\u062F\u0647 \u0648 \u067E\u0627\u06CC\u06CC\u0646\u060C \u0646\u06CC\u0645\u06CC \u0627\u0632 \u06A9\u0627\u0631 \u0631\u0627 \u0627\u0646\u062C\u0627\u0645 \u0645\u06CC\u200C\u062F\u0647\u062F.

\u062A\u0645\u0631\u06CC\u0646 \u067E\u06CC\u0634\u0646\u0647\u0627\u062F\u06CC: \u062F\u0647 \u062F\u0642\u06CC\u0642\u0647 \u0641\u0642\u0637 \u062A\u0648\u067E \u0631\u0627 \u0628\u0647 \u062F\u06CC\u0648\u0627\u0631 \u0628\u0632\u0646\u06CC\u062F \u0648 \u0628\u0631\u06AF\u0631\u062F\u0627\u0646\u06CC\u062F\u060C \u0628\u062F\u0648\u0646 \u0627\u06CC\u0646\u06A9\u0647 \u0627\u0645\u062A\u06CC\u0627\u0632\u06CC \u062F\u0631 \u06A9\u0627\u0631 \u0628\u0627\u0634\u062F.`,
      coverUrl: "/images/login/court-2.jpg",
      isPinned: false
    },
    {
      slug: "\u0627\u0641\u062A\u062A\u0627\u062D-\u0632\u0645\u06CC\u0646-\u0634\u0645\u0627\u0631\u0647-\u0633\u0647",
      title: "\u0632\u0645\u06CC\u0646 \u0634\u0645\u0627\u0631\u0647 \u06F3 \u0627\u0641\u062A\u062A\u0627\u062D \u0634\u062F",
      excerpt: "\u0632\u0645\u06CC\u0646 \u0631\u0648\u0628\u0627\u0632 \u0628\u0627 \u0646\u0648\u0631\u067E\u0631\u062F\u0627\u0632\u06CC LED \u0648 \u0686\u0645\u0646 \u0645\u0635\u0646\u0648\u0639\u06CC \u062F\u0631\u062C\u0647\u200C\u06CC\u06A9\u060C \u0627\u0632 \u0627\u06CC\u0646 \u0647\u0641\u062A\u0647 \u0642\u0627\u0628\u0644 \u0631\u0632\u0631\u0648 \u0627\u0633\u062A.",
      body: `\u0632\u0645\u06CC\u0646 \u0634\u0645\u0627\u0631\u0647 \u06F3 \u0628\u0627\u0634\u06AF\u0627\u0647 \u0627\u0632 \u0627\u06CC\u0646 \u0647\u0641\u062A\u0647 \u0622\u0645\u0627\u062F\u0647\u200C\u06CC \u0631\u0632\u0631\u0648 \u0627\u0633\u062A.

\u0627\u06CC\u0646 \u0632\u0645\u06CC\u0646 \u0631\u0648\u0628\u0627\u0632 \u0627\u0633\u062A\u060C \u0628\u0627 \u0646\u0648\u0631\u067E\u0631\u062F\u0627\u0632\u06CC LED \u06A9\u0647 \u0628\u0627\u0632\u06CC \u0634\u0628\u0627\u0646\u0647 \u0631\u0627 \u0647\u0645 \u0631\u0627\u062D\u062A \u0645\u06CC\u200C\u06A9\u0646\u062F\u060C \u0648 \u0686\u0645\u0646 \u0645\u0635\u0646\u0648\u0639\u06CC \u062F\u0631\u062C\u0647\u200C\u06CC\u06A9 \u06A9\u0647 \u0633\u0631\u0639\u062A \u062A\u0648\u067E \u0631\u0627 \u06A9\u0645\u06CC \u0628\u0627\u0644\u0627\u062A\u0631 \u0645\u06CC\u200C\u0628\u0631\u062F.

\u062A\u0627 \u067E\u0627\u06CC\u0627\u0646 \u0645\u0627\u0647\u060C \u0631\u0632\u0631\u0648 \u0627\u06CC\u0646 \u0632\u0645\u06CC\u0646 \u0628\u0627 \u06F2\u06F0\u066A \u062A\u062E\u0641\u06CC\u0641 \u0627\u0646\u062C\u0627\u0645 \u0645\u06CC\u200C\u0634\u0648\u062F.`,
      coverUrl: "/images/login/court-4.jpg",
      isPinned: false
    }
  ];
  for (const [index, a] of ARTICLES.entries()) {
    await prisma2.article.upsert({
      where: { slug: a.slug },
      update: {},
      create: {
        slug: a.slug,
        title: a.title,
        excerpt: a.excerpt,
        body: a.body,
        coverUrl: a.coverUrl,
        status: "PUBLISHED",
        isPinned: a.isPinned,
        publishedAt: new Date(Date.now() - (index + 1) * 3 * 864e5),
        authorId: admin.id
      }
    });
  }
  log(`\u2705 ${ARTICLES.length} \u0645\u0637\u0644\u0628 \u0646\u0645\u0648\u0646\u0647 \u0645\u0646\u062A\u0634\u0631 \u0634\u062F`);
  return { adminUsername, players: players.length, courts: COURTS.length };
}

// prisma/seed.ts
var prisma = new import_client.PrismaClient();
console.info("\u{1F3BE} \u0634\u0631\u0648\u0639 \u0645\u0642\u062F\u0627\u0631\u062F\u0647\u06CC \u0627\u0648\u0644\u06CC\u0647 \u067E\u0627\u06CC\u06AF\u0627\u0647 \u062F\u0627\u062F\u0647\u2026\n");
var essentialsOnly = process.env.SEED_ESSENTIALS_ONLY === "1";
runSeed(prisma, (line) => console.info(line), { essentialsOnly }).then(() => console.info("\n\u{1F389} \u0645\u0642\u062F\u0627\u0631\u062F\u0647\u06CC \u0627\u0648\u0644\u06CC\u0647 \u0628\u0627 \u0645\u0648\u0641\u0642\u06CC\u062A \u0627\u0646\u062C\u0627\u0645 \u0634\u062F.\n")).catch((error) => {
  console.error("\u274C \u062E\u0637\u0627 \u062F\u0631 \u0645\u0642\u062F\u0627\u0631\u062F\u0647\u06CC \u0627\u0648\u0644\u06CC\u0647:", error);
  process.exit(1);
}).finally(() => prisma.$disconnect());
